#include <qmainwindow.h>
#include <qcolor.h>

class QLabel;
class BodePlot;

class MainWin : public QMainWindow
{
    Q_OBJECT

public:
		QColor* colors;
		int n_colors;
    BodePlot *d_plot;


    MainWin(QString title, QWidget *p = 0, const char *name = 0,bool log=false);
    ~MainWin();

private slots:
    void plotMousePressed(const QMouseEvent &e);
    void plotMouseReleased(const QMouseEvent &e);
    void plotMouseMoved(const QMouseEvent &e);
    
    void print();
    void zoom(bool);

private:
    void showInfo(const QString &);


    QPoint d_p1;
    int d_zoom;
};
