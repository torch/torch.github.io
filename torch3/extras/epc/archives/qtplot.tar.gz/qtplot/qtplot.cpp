const char *help = "\
	GMM (c) Johnny Mariethoz & Co 2001\n\
	\n\
	This program is a graphical version of adplot \n";

#include <qapplication.h>
#include <qfileinfo.h>
#include <qtoolbar.h>
#include <qtoolbutton.h>
#include <qstatusbar.h>
#include <qhbox.h>
#include <qprinter.h>
#include <qregexp.h>
#include <qlabel.h>
#include <qwt_counter.h>
#include <qwt_math.h>
#include <qstring.h>
#include <qfile.h>
#include <qcolor.h>
#include "pixmaps.h"
#include "bode_plot.h"
#include "qtplot.h"
//torch include
#include <iostream>

#include "CmdLine.h"
#include "FileListCmdOption.h"

using namespace Torch;
using namespace std;
double** loadData(QString file_name, Allocator* allocator, int * n_values, int* n_columns);

class PrintFilter: public QwtPlotPrintFilter
{
	public:
		PrintFilter() {};

		virtual QFont font(const QFont &f, Item, int) const
		{
			QFont f2 = f;
			f2.setPointSize((int)(f.pointSize() * 1.25));
			return f2;
		}
};

//-----------------------------------------------------------------
//
//      bode.cpp -- A demo program featuring QwtPlot and QwtCounter
//
//      This example demonstrates the mapping of different curves
//      to different axes in a QwtPlot widget. It also shows how to
//      display the cursor position and how to implement zooming.
//
//-----------------------------------------------------------------

QString zoomInfo("Zoom: Press mouse button and drag");
QString cursorInfo("Cursor Pos: Press mouse button in plot region");

	MainWin::MainWin(QString title, QWidget *p , const char *name,bool log): 
QMainWindow(p, name)
{
	d_zoom = 0;

	d_plot = new BodePlot(this,title);
	d_plot->setLog(log);
	d_plot->setMargin(5);

	setCentralWidget(d_plot);

	QToolBar *toolBar = new QToolBar(this);

	QToolButton *btnZoom = new QToolButton(toolBar);
	btnZoom->setTextLabel("Zoom");
	btnZoom->setPixmap(zoom_xpm);
	btnZoom->setToggleButton(TRUE);
	btnZoom->setUsesTextLabel(TRUE);

	QToolButton *btnPrint = new QToolButton(toolBar);
	btnPrint->setTextLabel("Print");
	btnPrint->setPixmap(print_xpm);
	btnPrint->setUsesTextLabel(TRUE);

	toolBar->setStretchableWidget(new QWidget(toolBar));
	/*
		 QHBox *dampBox = new QHBox(toolBar);
		 dampBox->setSpacing(10);
		 (void)new QLabel("Damping Factor", dampBox);
		 QwtCounter *cntDamp = new QwtCounter(dampBox);
		 cntDamp->setRange(0.0, 5.0, 0.01);
		 cntDamp->setValue(0.0);

		 addToolBar(toolBar);
		 (void)statusBar();

		 showInfo(cursorInfo);

		 connect(cntDamp, SIGNAL(valueChanged(double)), 
		 d_plot, SLOT(setDamp(double))); 
	 */
	connect(btnPrint, SIGNAL(clicked()), SLOT(print()));
	connect(btnZoom, SIGNAL(toggled(bool)), SLOT(zoom(bool)));
	connect(d_plot, SIGNAL(plotMouseMoved(const QMouseEvent&)),
			SLOT(plotMouseMoved( const QMouseEvent&)));
	connect(d_plot, SIGNAL(plotMousePressed(const QMouseEvent &)),
			SLOT(plotMousePressed( const QMouseEvent&)));
	connect(d_plot, SIGNAL(plotMouseReleased(const QMouseEvent &)),
			SLOT(plotMouseReleased( const QMouseEvent&)));

	n_colors = 16;
	colors = (QColor*) malloc(sizeof(QColor)*n_colors);

	colors[0] =red;
	colors[1] =green;
	colors[2] =blue;
	colors[3] =cyan;
	colors[4] =magenta;
	colors[5] =yellow;
	colors[6] =darkRed;
	colors[7] =darkGreen;
	colors[8] =darkBlue;
	colors[9] =darkCyan;
	colors[10] =darkMagenta;
	colors[11] =darkYellow;
	colors[12] = black;
	colors[13] = darkGray;
	colors[14] = gray;
	colors[15] =lightGray;
}

void MainWin::print()
{
	QPrinter printer;

	QString docName = d_plot->title();
	if ( docName.isEmpty() )
	{
		docName.replace (QRegExp (QString::fromLatin1 ("\n")), tr (" -- "));
		printer.setDocName (docName);
	}

	printer.setCreator("Bode example");
	printer.setOrientation(QPrinter::Landscape);
	printer.setColorMode(QPrinter::Color);

	if (printer.setup())
		d_plot->print(printer, PrintFilter());
}

void MainWin::zoom(bool on)
{
	if (on)
	{
		d_zoom = TRUE;
	}
	else
	{
		// Disable Zooming.
		d_plot->setAxisAutoScale(QwtPlot::yLeft);
		d_plot->setAxisAutoScale(QwtPlot::yRight);
		d_plot->setAxisAutoScale(QwtPlot::xBottom);
		d_plot->replot();
		d_zoom = FALSE;
	}

	if (d_zoom)
		showInfo(zoomInfo);
	else
		showInfo(cursorInfo);
}

void MainWin::showInfo(const QString &text)
{
	statusBar()->message(text);
}

void MainWin::plotMouseMoved(const QMouseEvent &e)
{
	QString info;
	if(e.button() ==  RightButton)
		d_zoom = true;
	info.sprintf("X=%g, Y=%g",
			d_plot->invTransform(QwtPlot::xBottom, e.pos().x()),
			d_plot->invTransform(QwtPlot::yLeft, e.pos().y())
			);
	showInfo(info);
}

void MainWin::plotMousePressed(const QMouseEvent &e)
{
	// store position
	d_p1 = e.pos();

	// update cursor pos display
	plotMouseMoved(e);

	if (d_zoom)
		d_plot->setOutlineStyle(Qwt::Rect); 
	else
		d_plot->setOutlineStyle(Qwt::Cross);
}

void MainWin::plotMouseReleased(const QMouseEvent &e)
{
	// some shortcuts
	int axl= QwtPlot::yLeft, axr = QwtPlot::yRight, axb= QwtPlot::xBottom;

	if (d_zoom)
	{
		// Don't invert any scales which aren't inverted
		int x1 = qwtMin(d_p1.x(), e.pos().x());
		int x2 = qwtMax(d_p1.x(), e.pos().x());
		int y1 = qwtMin(d_p1.y(), e.pos().y());
		int y2 = qwtMax(d_p1.y(), e.pos().y());

		// limit selected area to a minimum of 11x11 points
		int lim = 5 - (y2 - y1) / 2;
		if (lim > 0)
		{
			y1 -= lim;
			y2 += lim;
		}
		lim = 5 - (x2 - x1 + 1) / 2;
		if (lim > 0)
		{
			x1 -= lim;
			x2 += lim;
		}

		// Set fixed scales
		d_plot->setAxisScale(axl, 
				d_plot->invTransform(axl,y1), d_plot->invTransform(axl,y2));
		d_plot->setAxisScale(axr, 
				d_plot->invTransform(axr,y1), d_plot->invTransform(axr,y2));
		d_plot->setAxisScale(axb, 
				d_plot->invTransform(axb,x1), d_plot->invTransform(axb,x2));
		d_plot->replot();

		showInfo(cursorInfo);
		d_plot->setOutlineStyle(Qwt::Triangle);
		d_zoom = FALSE;
	}
}

MainWin::~MainWin(){

}

double** loadData(QString file_name, Allocator* allocator, int * n_values, int* n_columns){
	QFile f (file_name);
	QRegExp ws("\\s+");
	f.open(IO_ReadOnly);
	cout << file_name;
	QTextStream qts(&f);
	QString current_line = NULL;

	//find the number of lines
	int n_lines=0;
	current_line = qts.readLine();
	if(current_line == NULL){
		error("No line on the file\n");
		exit(-1);
	}
	QStringList vals = QStringList::split( ws, current_line );
	int n_cols = 0;
	for ( QStringList::Iterator it = vals.begin(); it != vals.end(); ++it ) 
		n_cols++;

	while(current_line != NULL){
		current_line = qts.readLine();
		n_lines++;
	}
	f.close();

	//allocation memory
	double** value = (double**) allocator->alloc(n_cols*sizeof(double*));
	for(int i=0;i<n_cols;i++)
		value[i] = (double*)allocator->alloc(n_lines*sizeof(double));

	message("loaded %d values on n: %d cols",n_lines, n_cols);
	f.open(IO_ReadOnly);
	for(int i=0;i<n_lines;i++){
		current_line = qts.readLine();
		vals = QStringList::split( ws, current_line );
		int j=0;
		for ( QStringList::Iterator it = vals.begin(); it != vals.end(); ++it,j++ ) {
			value[j][i] = (*it).toDouble();
		}
	}
	f.close();
	*n_columns= n_cols;
	*n_values = n_lines;
	return (value);
}

int main (int argc, char **argv)
{
	int column;
	int xcolumn;
	char* title;
	char* x_legend;
	char* y_legend;
	bool log;

	FileListCmdOption file_list("file name", "the list files or one data file");
	file_list.isArgument(true);

	CmdLine cmd;
	// Put the help line at the beginning
	cmd.info(help);

	// Train mode
	cmd.addText("\nArguments:");
	cmd.addCmdOption(&file_list);

	cmd.addText("\nOptions:");
	cmd.addICmdOption("-ycol", &column, 0, "column containing y values");
	cmd.addBCmdOption("-log", &log,false, "log-log axis");
	cmd.addICmdOption("-xcol", &xcolumn, -1, "column containing x values");
	cmd.addSCmdOption("-title", &title, "Graphics", "title of the graphic");
	cmd.addSCmdOption("-xl", &x_legend, "X", "legend on X axis");
	cmd.addSCmdOption("-yl", &y_legend, "Y", "legend on Y axis");

	cmd.read(argc, argv);
	Allocator allocator;

	QApplication a(argc, argv);
	QString stitle(title);
	MainWin w(stitle,NULL,"QtPlot",log);
	if(w.n_colors < file_list.n_files){
		error("Number of files limited at (%d)",w.n_colors);
	}
	w.d_plot->setAxisTitle(QwtPlot::xBottom,x_legend);
	w.d_plot->setAxisTitle(QwtPlot::yLeft,y_legend);

	for(int i=0;i<file_list.n_files;i++){
		int n_values, n_cols;
		QString f(file_list.file_names[i]);
		double** vals = loadData(f,&allocator,&n_values, &n_cols);
		if(!(column < n_cols || (xcolumn < n_cols && xcolumn >1))){
			error("the column (%d) should be smaler thant the number of column (%d)",column,n_cols);
			exit(-1);
		}
		double* x = NULL;
		if(xcolumn < 0){
			x = (double*)allocator.alloc(n_values*sizeof(double));
			for(int j=1;j<=n_values;j++)
				x[j-1]=j;
		}

		QFileInfo fi(f);

		QPen pen(w.colors[i],2,Qt::SolidLine,Qt::FlatCap,Qt::BevelJoin);
		if(x == NULL)
			w.d_plot->showData(vals[xcolumn],vals[column],n_values,f,fi.fileName(),pen);
		else
			w.d_plot->showData(x,vals[column],n_values,f,fi.fileName(),pen);

		w.d_plot->show();
		allocator.free(vals);
	}
	a.setMainWidget(&w);
	w.resize(540,400);
	w.show();

	int rv = a.exec();
	return rv;
}
