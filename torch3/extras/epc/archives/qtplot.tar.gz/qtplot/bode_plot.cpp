#include <qwt_math.h>
#include "bode_plot.h"

BodePlot::BodePlot(QWidget *parent,QString title):
    QwtPlot(parent)
{
    setTitle(title);

    setCanvasBackground(white);

    // outline
    enableOutline(TRUE);
    setOutlinePen(green);

    // legend
    setAutoLegend(TRUE);
    enableLegend(TRUE);
    setLegendPos(Qwt::Right);
    setLegendFrameStyle(QFrame::Box|QFrame::Sunken);

    // grid 
    //enableGridXMin();
		//enableGridX(false);
		//enableGridY(false);
    //setGridMajPen(QPen(white, 0, DotLine));
    //setGridMinPen(QPen(gray, 0 , DotLine));

    // axes
    //enableAxis(QwtPlot::yRight);
    setAxisTitle(QwtPlot::xBottom, "X");
    setAxisTitle(QwtPlot::yLeft, "Y");
    //setAxisTitle(QwtPlot::yRight, "Phase [deg]");

    //setAxisOptions(QwtPlot::xBottom, QwtAutoScale::Logarithmic);
    //setAxisMaxMajor(QwtPlot::xBottom, 6);
    //setAxisMaxMinor(QwtPlot::xBottom, 10);
  
    // curves
    //crv1 = insertCurve("Amplitude");
    //setCurvePen(crv1, QPen(yellow));
    //setCurveYAxis(crv1, QwtPlot::yLeft);

    //crv2 = insertCurve( "Phase");
    //setCurvePen(crv2, QPen(cyan));
    //setCurveYAxis(crv2, QwtPlot::yRight);
    
    // marker
		/*
    mrk1 = insertMarker();
    setMarkerLineStyle(mrk1, QwtMarker::VLine);
    setMarkerPos(mrk1, 0.0,0.0);
    setMarkerLabelAlign(mrk1, AlignRight|AlignBottom);
    setMarkerPen(mrk1, QPen(green, 0, DashDotLine));
    setMarkerFont(mrk1, QFont("Helvetica", 10, QFont::Bold));
		*/

    mrk2 = insertLineMarker("", QwtPlot::yLeft);
    setMarkerLabelAlign(mrk2, AlignRight|AlignBottom);
    setMarkerPen(mrk2, QPen(QColor(200,150,0), 0, DashDotLine));
    setMarkerFont(mrk2, QFont("Helvetica", 10, QFont::Bold));
    setMarkerSymbol(mrk2, 
				QwtSymbol(QwtSymbol::Diamond, yellow, green, QSize(7,7)));

    //setDamp(0.0);
}

void BodePlot::showData(double *x, double *y,
    int n, QString key, QString legend, QPen pen)
{
    long crv = insertCurve(key);
    setCurveYAxis(crv, QwtPlot::yLeft);
    setCurveRawData(crv, x, y, n);
		setCurveTitle(crv,legend);
		if(n == 1){
			QwtSymbol sym;
			sym.setStyle(QwtSymbol::XCross);
			sym.setPen(pen);
			sym.setSize(10);
			setCurveSymbol(crv,sym);
			setCurveStyle(crv, QwtCurve::NoCurve);
		}else{
			setCurvePen(crv, pen);
			}
		replot();
}

void BodePlot::setLog(bool log){
	if(log){
		setAxisOptions(QwtPlot::xBottom, QwtAutoScale::Logarithmic);
		setAxisOptions(QwtPlot::yLeft, QwtAutoScale::Logarithmic);
	}
}
