#include <qwt_plot.h>

class BodePlot: public QwtPlot
{
    Q_OBJECT
public:
    BodePlot(QWidget *parent, QString title);
		void showData(double *x, double *y,
				int n, QString key, QString legend, QPen pen);
		void setLog(bool log);

private:
    long mrk1, mrk2;
};
